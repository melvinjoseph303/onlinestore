class AddAttributesToShops < ActiveRecord::Migration
  def change
    add_column :shops, :name, :string
    add_column :shops, :address, :text
    add_column :shops, :user_id, :integer
  end
end
