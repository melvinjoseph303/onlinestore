class CreateProducts < ActiveRecord::Migration
  def change
    create_table :products do |t|
      t.string :brand
      t.string :model
      t.text :description
      t.string :title
      t.decimal :price, precision: 5, scale: 2, default: 0

      t.timestamps null: false
    end
  end
end
