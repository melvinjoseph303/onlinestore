class UserMailer < ApplicationMailer
   default from: 'ajildd10@gmail.com'
   
   def order_creation_email(user)
      @user = user
      @url  = 'http://www.gmail.com'
      mail(to: @user.email, subject: 'Order is created')
  end
  
   def order_deletion_email(user)
      @user = user
      @url  = 'http://www.gmail.com'
      mail(to: @user.email, subject: 'Order is cancelled')
   end
end
