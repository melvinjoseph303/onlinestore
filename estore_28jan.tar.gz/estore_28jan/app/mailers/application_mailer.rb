class ApplicationMailer < ActionMailer::Base
  #default from: "from@example.com"
  default from: "ajildd10@gmail.com"
  layout 'mailer'
end
