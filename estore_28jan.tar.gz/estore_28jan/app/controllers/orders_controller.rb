class OrdersController < ApplicationController
  include CurrentCart
  before_action :set_cart
  def index
    #@order=@cart.order
  end
  
  def new
    puts "cart_in_orders_cnt"+@cart.line_items.inspect
    #@order=@cart.order
    #@order=@cart.line_items
    @order=Order.new
    @order.cart_id=@cart.id
    @order.sub_total=@cart.total_price
  end
  
  def create
    puts "cart_in_orders_cnt"+@cart.inspect
    #@order=@cart.order
    #@order=@cart.line_items
    @order=Order.new
    @order.cart_id=@cart.id
    @order.sub_total=@cart.total_price
    if @order.update_attributes(order_params.merge(status:'open'))
      session[:cart_id]=nil
      redirect_to root_path
    else
      render :new
    end
  end
  
  def order_params
    params.require(:order).permit(:first_name, :last_name)
  end
  
end
