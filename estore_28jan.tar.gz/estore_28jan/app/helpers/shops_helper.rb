module ShopsHelper
    def shop_author(shop)
      user_signed_in? && current_user.id == shop.user_id
    end
end
