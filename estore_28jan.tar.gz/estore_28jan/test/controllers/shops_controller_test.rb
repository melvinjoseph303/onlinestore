require 'test_helper'

class ShopsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
